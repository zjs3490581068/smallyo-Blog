﻿//从键盘输入一个32位的二进制形式的IP地址，将其转换为点分十进制的表示，
// 如果输入的字符串中含有1和0以外的字符，则输出“该字符串不是正确的IP地址”。     
// 输入：0、1二进制序列，不会超过32位，位数不足时程序自动在前面补0.
// 输出：点分IP地址。
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <math.h>
#include <string.h>

int main()
{
	char a[33];
	char b[33] = { '0'};
	scanf("%s", a);
	int size = strlen(a);
	for (int y = 0; y < size; y++) {
		if (a[y] != '0' && a[y] != '1') {
			printf("该字符串不是正确的IP地址");
			return 0;
		}
	}
	int i = 0;
	for ( i = 0; i < 32 - size; i++) {
		b[i] = '0';
	}
	for (int k = 0; k < size; k++) {
		b[i] = a[k];
		i++;
	}
	b[32] = '\0';
	int c[5] = { 0 };
	int j = 0;
	for (int m = 0; m < 33; m+=8) {
		int count = 0;
		int sum = 0;
		for (int n = m+7; n >=m; n--) {
			int a = b[n] - '0';
			sum += pow(2, count) * a;
			count++;
		}
		c[j] = sum;
		j++;
	}
	for (int x = 0; x < 4; x++) {
		if (x != 0) {
			printf(".");
		}
		printf("%d", c[x]);
	}
	return 0;
}