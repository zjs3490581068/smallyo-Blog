#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int num;
    int data;
    struct Node* next;
    struct Node* prev;
} Node;

Node* CreateList(int n) {
    Node* head = (Node*)malloc(sizeof(Node));
    int x;
    scanf("%d", &x);
    head->data = x;
    head->num = 1;
    Node* p = head;
    for (int i = 1; i < n; i++) {
        Node* newNode = (Node*)malloc(sizeof(Node));
        scanf("%d", &x);
        newNode->data = x;
        newNode->num = i + 1;
        newNode->prev = p;
        p->next = newNode;
        p = newNode;
    }
    p->next = head; //�γɻ�
    head->prev = p;
    return head;
}

void destoryNode(Node* p) {
    Node* temp = p;
    p->prev->next = temp->next;
    p = temp->next;
    free(temp);
}

int Josephus(Node* head, int m) {
    Node* p = head;
    int count = 1;
    while (p->next != p) {
        if (count != m) {
            p = p->next;
            count++;
        }
        else {
            printf("%d ", p->num);
            m = p->data;
            Node* temp = p;
            p->prev->next = temp->next;
			temp->next->prev = p->prev;
            p = temp->next;
            free(temp);
            count = 1;
        }
    }
    printf("%d\n", p->num);
}

int main() {
    int n, m;
    printf("�����������ͳ�ʼ����ֵ��");
    scanf("%d %d", &n, &m);
    printf("������ÿ���˵����룺");
    Node* head = CreateList(n);
    printf("����˳��Ϊ��");
    Josephus(head, m);
    return 0;
}