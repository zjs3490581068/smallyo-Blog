#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>


int main()
{
	char a[201];
	scanf("%s", a);
	int j = 0;
	char b[201];
	for (int i = 0; i < 201; i++) {
		if (a[i] != '*') {
			for (int k = i; k < 201; k++) {
				if (a[k] != '\0') {
					b[j] = a[k];
					j++;
				}
				else if (a[k] == '\0') {
					break;
				}
			}
			break;
		}
	}
	for (int i = 0; i < 201; i++) {
		if (a[i] == '*') {
			b[j] = '*';
			j++;
		}
		else {
			break;
		}
	}
	b[j] = '\0';
	printf("%s", b);
	return 0;
}